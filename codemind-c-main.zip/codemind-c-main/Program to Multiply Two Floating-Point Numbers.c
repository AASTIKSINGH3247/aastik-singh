#include<stdio.h>
int main()
{
    float a,b;
    scanf("%f %f",&a,&b);
    printf("%0.2f",a*b);
    return 0;
}