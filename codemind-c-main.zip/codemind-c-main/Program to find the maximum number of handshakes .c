#include<stdio.h>
int main()
{
int n,h;
scanf("%d",&n);
h=n*(n-1)/2;
printf("%d",h);
return 0;
}