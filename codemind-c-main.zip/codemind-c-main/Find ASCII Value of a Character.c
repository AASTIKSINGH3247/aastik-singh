#include<stdio.h>
int main()
{
  char ch;   
  
  scanf("%c",&ch);
  printf("%d",ch);
  
  return 0;
}