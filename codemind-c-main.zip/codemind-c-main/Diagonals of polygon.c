#include<stdio.h>
int main()
{
int n,s;
scanf("%d",&n);
s=n*(n-3)/2;
printf("%d",s);
return 0;
}