#include<stdio.h>
int main()
{
int P,T,R,SI;
scanf("%d %d %d",&P,&T,&R);
SI=(P*T*R)/100,
printf("%d",SI);
return 0;
}