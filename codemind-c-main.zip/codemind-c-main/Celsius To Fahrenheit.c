#include<stdio.h>
int main()
{
    float fr,c;
    scanf("%f",&c);
    fr=(c*9/5)+32;
    printf("%0.2f",fr);
    return 0;
}