#include<stdio.h>
int main()
{
int a,b,mul;
scanf("%d %d",&a,&b);
mul=a*b;
printf("%d",mul);
return 0;
}