#include<stdio.h>
int main()
{
float a,b,ave;
scanf("%f %f",&a,&b);
ave=(a+b)/2;
printf("%0.4f",ave);
return 0;
}