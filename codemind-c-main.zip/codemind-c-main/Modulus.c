#include<stdio.h>
int main()
{
int a,b,mod;
scanf("%d %d",&a,&b);
mod=a%b;
printf("%d",mod);
return 0;
}