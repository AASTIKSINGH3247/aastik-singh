#include<stdio.h>
int main()
{
int a,b,divi;
scanf("%d %d",&a,&b);
divi=a/b;
printf("%d",divi);
return 0;
}