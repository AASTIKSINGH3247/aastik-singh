#include<stdio.h>
int main()
{
char a[100],b[100],c[50];
scanf("%s %s %s",a,b,c);
printf("%s %s %s",a,b,c);
return 0;
}