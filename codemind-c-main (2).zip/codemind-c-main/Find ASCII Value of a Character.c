#include<stdio.h>
int main()
{
    char x;
    scanf("%c",&x);
    printf("%d",x);
}