#include<stdio.h>
int main()
{
    int p=100,t=20,r=10,s;
    scanf("%d%d%d",&p,&t,&r);
    s=(p*t*r)/100;
    printf("%d",s);
}