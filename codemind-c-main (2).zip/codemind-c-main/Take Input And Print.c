#include<stdio.h>
int main()
{
    char m[20];
    scanf("%s",m);
    printf("%s",m);
    gets(m);
    puts(m);
}