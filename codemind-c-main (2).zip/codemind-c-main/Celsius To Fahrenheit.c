#include<stdio.h>
int main()
{
    float n;
    scanf("%f",&n);
    printf("%.2f",(1.8*n)+32);
}