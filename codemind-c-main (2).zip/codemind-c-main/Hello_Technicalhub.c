#include<stdio.h>
int main()
{
    char str[1000];
    scanf("%[^
]s",str);
    printf("Hello Technicalhub
");
    printf("%s",str);
}