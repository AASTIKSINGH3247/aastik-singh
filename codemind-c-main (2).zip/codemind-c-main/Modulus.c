#include<stdio.h>
int main()
{
    int x,y;
    scanf("%d%d",&y,&x);
    printf("%d",y%x);
}