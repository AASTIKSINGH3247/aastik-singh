#include<stdio.h>
int main()
{
    float f;
    scanf("%f",&f);
    printf("%.2f",(f-32)*5/9);
}