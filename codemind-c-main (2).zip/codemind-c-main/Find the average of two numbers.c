#include<stdio.h>
int main()
{
    float a,x,y;
    scanf("%f%f",&x,&y);
    a=(x+y)/2;
    printf("%.4f",a);
}